import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-semibold ring-offset-background transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow-primary hover:bg-primary/90 hover:-translate-y-0.5 hover:shadow-lg active:scale-[0.98]",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border-2 border-foreground bg-transparent text-foreground hover:bg-foreground hover:text-background hover:-translate-y-0.5",
        secondary: "bg-secondary text-secondary-foreground shadow-secondary hover:bg-secondary/90 hover:-translate-y-0.5 hover:shadow-lg active:scale-[0.98]",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
        hero: "bg-primary text-primary-foreground shadow-primary px-12 py-6 text-lg font-bold rounded-2xl hover:bg-primary/90 hover:-translate-y-1 hover:shadow-xl active:scale-[0.98]",
        heroOutline: "border-3 border-foreground bg-transparent text-foreground px-12 py-6 text-lg font-bold rounded-2xl hover:bg-foreground hover:text-background hover:-translate-y-1",
        accent: "bg-accent text-accent-foreground shadow-accent hover:bg-accent/90 hover:-translate-y-0.5 hover:shadow-lg active:scale-[0.98]",
        success: "bg-success text-success-foreground hover:bg-success/90 hover:-translate-y-0.5 active:scale-[0.98]",
        glass: "bg-white/70 backdrop-blur-xl border border-white/20 text-foreground hover:bg-white/90 hover:-translate-y-0.5",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-lg px-3",
        lg: "h-12 rounded-xl px-8 text-base",
        xl: "h-14 rounded-2xl px-10 text-lg",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
